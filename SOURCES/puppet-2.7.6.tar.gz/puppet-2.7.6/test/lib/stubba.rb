# for backwards compatibility
require 'mocha'
