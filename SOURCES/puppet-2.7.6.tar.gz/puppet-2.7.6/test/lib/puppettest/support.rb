require 'puppettest'

module PuppetTest::Support
end

require 'puppettest/support/assertions'
require 'puppettest/support/helpers'
require 'puppettest/support/utils'
